class ArticleAlreadySuggested(Exception):
    pass

