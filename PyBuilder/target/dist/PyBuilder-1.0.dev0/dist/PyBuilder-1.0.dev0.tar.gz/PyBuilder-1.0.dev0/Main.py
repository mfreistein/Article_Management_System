"""
starts the program by calling the Login page
"""
import Login


def main():
    """
    starts the program by calling the Login page
    """
    Login.login_page()


main()
