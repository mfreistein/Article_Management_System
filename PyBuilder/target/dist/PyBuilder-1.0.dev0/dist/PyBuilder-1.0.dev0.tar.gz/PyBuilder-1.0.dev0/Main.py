import Login

def main():
    """
    MAIN METHOD
    """
    Login.login_page()


main()

